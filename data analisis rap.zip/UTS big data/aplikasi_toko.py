import sqlite3
from decimal import Decimal

# Koneksi ke database
conn = sqlite3.connect('shop.db')
cursor = conn.cursor()

# Membuat tabel jika belum ada
cursor.execute('''CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT,
                    price DECIMAL(10, 2),
                    stock INTEGER)''')

cursor.execute('''CREATE TABLE IF NOT EXISTS employees (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT,
                    position TEXT)''')

cursor.execute('''CREATE TABLE IF NOT EXISTS transactions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    item_id INTEGER,
                    quantity INTEGER,
                    total_price DECIMAL(10, 2),
                    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (item_id) REFERENCES items(id))''')

# Fungsi untuk menambahkan barang
def tambah_barang():
    nama = input("Masukkan nama barang: ")
    harga = Decimal(input("Masukkan harga barang: "))
    stok = int(input("Masukkan stok barang: "))
    cursor.execute("INSERT INTO items (name, price, stock) VALUES (?, ?, ?)", (nama, harga, stok))
    conn.commit()
    print("Barang berhasil ditambahkan.")

# Fungsi untuk menampilkan semua barang
def tampilkan_semua_barang():
    cursor.execute("SELECT * FROM items")
    for item in cursor.fetchall():
        print(item)

# Fungsi untuk menambahkan karyawan
def tambah_karyawan():
    nama = input("Masukkan nama karyawan: ")
    posisi = input("Masukkan posisi karyawan: ")
    cursor.execute("INSERT INTO employees (name, position) VALUES (?, ?)", (nama, posisi))
    conn.commit()
    print("Karyawan berhasil ditambahkan.")

# Fungsi untuk menampilkan semua karyawan
def tampilkan_semua_karyawan():
    cursor.execute("SELECT * FROM employees")
    for employee in cursor.fetchall():
        print(employee)

# Fungsi untuk menambahkan transaksi
def tambah_transaksi():
    item_id = int(input("Masukkan ID barang: "))
    quantity = int(input("Masukkan jumlah: "))
    cursor.execute("SELECT price FROM items WHERE id = ?", (item_id,))
    harga = cursor.fetchone()
    
    if harga:
        total_harga = harga[0] * quantity
        cursor.execute("INSERT INTO transactions (item_id, quantity, total_price) VALUES (?, ?, ?)", 
                       (item_id, quantity, total_harga))
        conn.commit()
        print("Transaksi berhasil ditambahkan.")
    else:
        print("Barang tidak ditemukan.")

# Fungsi untuk menampilkan semua transaksi
def tampilkan_semua_transaksi():
    cursor.execute("SELECT * FROM transactions")
    for transaction in cursor.fetchall():
        print(transaction)

# Menu aplikasi
def menu():
    while True:
        print("\n=== Aplikasi Toko ===")
        print("1. Tambah barang")
        print("2. Tampilkan semua barang")
        print("3. Tambah karyawan")
        print("4. Tampilkan semua karyawan")
        print("5. Tambah transaksi")
        print("6. Tampilkan semua transaksi")
        print("7. Keluar")
        pilihan = input("Pilih opsi (1/2/3/4/5/6/7): ")

        if pilihan == '1':
            tambah_barang()
        elif pilihan == '2':
            tampilkan_semua_barang()
        elif pilihan == '3':
            tambah_karyawan()
        elif pilihan == '4':
            tampilkan_semua_karyawan()
        elif pilihan == '5':
            tambah_transaksi()
        elif pilihan == '6':
            tampilkan_semua_transaksi()
        elif pilihan == '7':
            print("Keluar dari aplikasi.")
            break
        else:
            print("Pilihan tidak valid. Coba lagi.")

# Menjalankan aplikasi
if __name__ == "__main__":
    menu()

# Menutup koneksi database saat aplikasi selesai
conn.close()
