
import sqlite3

# Koneksi ke database
conn = sqlite3.connect('toko.db')
cursor = conn.cursor()

# Tampilkan data barang yang ada
def tampilkan_data_barang():
    cursor.execute("SELECT * FROM barang")
    data_barang = cursor.fetchall()
    for barang in data_barang:
        print(barang)

# Tambah data barang baru
def tambah_data_barang(nama_barang, harga, stok):
    cursor.execute("INSERT INTO barang (nama_barang, harga, stok) VALUES (?, ?, ?)", (nama_barang, harga, stok))
    conn.commit()
    print("Data barang baru berhasil ditambahkan.")

# Tampilkan data barang yang baru
def tampilkan_data_barang_baru():
    tampilkan_data_barang()

# Contoh penggunaan fungsi
if __name__ == "__main__":
    # Menampilkan data barang yang ada
    print("Data barang yang ada:")
    tampilkan_data_barang()

    # Menambah data barang baru
    nama_barang = 'BarangD'
    harga = 30000
    stok = 15
    tambah_data_barang(nama_barang, harga, stok)

    # Menampilkan data barang setelah penambahan
    print("Data barang yang baru:")
    tampilkan_data_barang_baru()

# Tutup koneksi
conn.close()
